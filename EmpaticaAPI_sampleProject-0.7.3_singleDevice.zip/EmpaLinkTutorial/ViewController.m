//
//  ViewController.m
//  EmpaLinkTutorial
//
//  Created by Alberto Guarino on 05/12/14.
//  Copyright (c) 2014 Empatica. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (IBAction)scanForDevicesAndConnectPressed:(id)sender {
    [EmpaticaAPI discoverDevicesWithDelegate:self];
}

- (void)didDiscoverDevices:(NSArray *)devices {
    if (devices.count > 0) {
        // Print names of available devices
        for (EmpaticaDeviceManager *device in devices) {
            NSLog(@"Device: %@", device.name);
        }
        
        // Connect to first available device
        EmpaticaDeviceManager *firstDevice = [devices objectAtIndex:0];
        [firstDevice connectWithDeviceDelegate:self];
    } else {
        NSLog(@"No device found in range");
    }
}

- (void)didUpdateBLEStatus:(BLEStatus)status {
    switch (status) {
        case kBLEStatusNotAvailable:
            NSLog(@"Bluetooth low energy not available");
            break;
        case kBLEStatusReady:
            NSLog(@"Bluetooth low energy ready");
            break;
        case kBLEStatusScanning:
            NSLog(@"Bluetooth low energy scanning for devices");
            break;
        default:
            break;
    }
}

- (void)didUpdateDeviceStatus:(DeviceStatus)status forDevice:(EmpaticaDeviceManager *)device {
    switch (status) {
        case kDeviceStatusDisconnected:
            NSLog(@"Device Disconnected");
            break;
        case kDeviceStatusConnecting:
            NSLog(@"Device Connecting");
            break;
        case kDeviceStatusConnected:
            NSLog(@"Device Connected");
            break;
        case kDeviceStatusDisconnecting:
            NSLog(@"Device Disconnecting");
            break;
        default:
            break;
    }
}

- (void)didReceiveAccelerationX:(char)x y:(char)y z:(char)z withTimestamp:(double)timestamp fromDevice:(EmpaticaDeviceManager *)device {
//    NSLog(@"Acceleration (x,y,z) received: (%d,%d,%d) at timestamp %f", x, y, z, timestamp);
}

- (void)didReceiveBatteryLevel:(float)level withTimestamp:(double)timestamp fromDevice:(EmpaticaDeviceManager *)device {
//    NSLog(@"Battery level received: %.2f at timestamp %f", level, timestamp);
}

- (void)didReceiveBVP:(float)bvp withTimestamp:(double)timestamp fromDevice:(EmpaticaDeviceManager *)device {
//    NSLog(@"BVP received: %f at timestamp %f", bvp, timestamp);
}

- (void)didReceiveGSR:(float)gsr withTimestamp:(double)timestamp fromDevice:(EmpaticaDeviceManager *)device {
    NSLog(@"GSR received: %f at timestamp %f", gsr, timestamp);
}

- (void)didReceiveIBI:(float)ibi withTimestamp:(double)timestamp fromDevice:(EmpaticaDeviceManager *)device {
//    NSLog(@"IBI received: %f at timestamp %f", ibi, timestamp);
}

- (void)didReceiveTemperature:(float)temp withTimestamp:(double)timestamp fromDevice:(EmpaticaDeviceManager *)device {
//    NSLog(@"Temperature received: %.2f at timestamp %f", temp, timestamp);
}

-(void)didReceiveTagAtTimestamp:(double)timestamp fromDevice:(EmpaticaDeviceManager *)device{
    NSLog(@"Tag received at timestamp %f", timestamp);
}

@end
