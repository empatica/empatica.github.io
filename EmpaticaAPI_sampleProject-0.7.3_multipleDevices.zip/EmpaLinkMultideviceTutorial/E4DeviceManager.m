//
//  E4DeviceManager.m
//  EmpaLinkMultideviceTutorial
//
//  Created by Alberto Guarino on 05/12/14.
//  Copyright (c) 2014 Empatica. All rights reserved.
//

#import "E4DeviceManager.h"

@interface E4DeviceManager()
@end

@implementation E4DeviceManager

- (void)didUpdateDeviceStatus:(DeviceStatus)status forDevice:(EmpaticaDeviceManager *)device {
    switch (status) {
        case kDeviceStatusDisconnected:
            NSLog(@"Device %@ Disconnected", device.name);
            break;
        case kDeviceStatusConnecting:
            NSLog(@"Device %@ Connecting", device.name);
            break;
        case kDeviceStatusConnected:
            NSLog(@"Device %@ Connected", device.name);
            break;
        case kDeviceStatusDisconnecting:
            NSLog(@"Device %@ Disconnecting", device.name);
        default:
            break;
    }
}

-(void)didReceiveTagAtTimestamp:(double)timestamp fromDevice:(EmpaticaDeviceManager *)device{
    NSLog(@"[%@] Tag received at timestamp %f", device.name, timestamp);
}

- (void)didReceiveAccelerationX:(char)x y:(char)y z:(char)z withTimestamp:(double)timestamp fromDevice:(EmpaticaDeviceManager *)device {
//    NSLog(@"[%@] Acceleration (x,y,z) received: (%d,%d,%d) at timestamp %f", device.name, x, y, z, timestamp);
}

- (void)didReceiveBatteryLevel:(float)level withTimestamp:(double)timestamp fromDevice:(EmpaticaDeviceManager *)device {
//    NSLog(@"[%@] Battery level received: %.2f at timestamp %f", device.name, level, timestamp);
}

- (void)didReceiveBVP:(float)bvp withTimestamp:(double)timestamp fromDevice:(EmpaticaDeviceManager *)device {
//    NSLog(@"[%@] BVP received: %f at timestamp %f", device.name, bvp, timestamp);
}

- (void)didReceiveGSR:(float)gsr withTimestamp:(double)timestamp fromDevice:(EmpaticaDeviceManager *)device {
    NSLog(@"[%@] GSR received: %f at timestamp %f", device.name, gsr, timestamp);
}

- (void)didReceiveIBI:(float)ibi withTimestamp:(double)timestamp fromDevice:(EmpaticaDeviceManager *)device {
//    NSLog(@"[%@] IBI received: %f at timestamp %f", device.name, ibi, timestamp);
}

- (void)didReceiveTemperature:(float)temp withTimestamp:(double)timestamp fromDevice:(EmpaticaDeviceManager *)device {
//    NSLog(@"[%@] Temperature received: %.2f at timestamp %f", device.name, temp, timestamp);
}

@end
