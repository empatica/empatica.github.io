//
//  AppDelegate.m
//  EmpaLinkMultideviceTutorial
//
//  Created by Alberto Guarino on 05/12/14.
//  Copyright (c) 2014 Empatica. All rights reserved.
//

#import "AppDelegate.h"
#import <EmpaLink-ios-0.7-full/EmpaticaAPI-0.7.h>

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    #error You need to replace EMPATICA_API_KEY with your Empatica API key
    [EmpaticaAPI authenticateWithAPIKey:@"EMPATICA_API_KEY" andCompletionHandler:^(BOOL success, NSString *description) {
        NSLog(@"authenticateWithAPIKey returned: %@", success?@"OK":@"ERROR");
    }];

    return YES;
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
	[EmpaticaAPI prepareForBackground];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
	[EmpaticaAPI prepareForResume];
}

@end
