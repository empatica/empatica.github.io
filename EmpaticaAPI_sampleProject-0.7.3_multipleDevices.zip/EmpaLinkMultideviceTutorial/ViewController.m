//
//  ViewController.m
//  EmpaLinkMultideviceTutorial
//
//  Created by Alberto Guarino on 05/12/14.
//  Copyright (c) 2014 Empatica. All rights reserved.
//

#import "ViewController.h"

@interface ViewController()

@property (nonatomic, strong) NSMutableArray *E4DeviceManagers;

@end

@implementation ViewController

-(void)viewdidload{
    _E4DeviceManagers = [[NSMutableArray alloc ] init];
}

- (IBAction)scanForDevicesAndConnectPressed:(id)sender {
    [EmpaticaAPI discoverDevicesWithDelegate:self];
}

- (void)didDiscoverDevices:(NSArray *)devices {
    if (devices.count > 0) {
        for (EmpaticaDeviceManager *device in devices) {
            NSLog(@"Device %@ Discovered", device.name);
            
            // Create a DeviceManager for each device
            E4DeviceManager *manager = [[E4DeviceManager alloc] init];
            [_E4DeviceManagers addObject:manager];

            // Connect to E4 device
            [device connectWithDeviceDelegate:manager];
        }
    } else {
        NSLog(@"No devices found in range");
    }
}

- (void)didUpdateBLEStatus:(BLEStatus)status {
    switch (status) {
        case kBLEStatusNotAvailable:
            NSLog(@"Bluetooth low energy not available");
            break;
        case kBLEStatusReady:
            NSLog(@"Bluetooth low energy ready");
            break;
        case kBLEStatusScanning:
            NSLog(@"Bluetooth low energy scanning for devices");
            break;
        default:
            break;
    }
}

@end
