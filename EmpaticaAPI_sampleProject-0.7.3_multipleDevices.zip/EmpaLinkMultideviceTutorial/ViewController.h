//
//  ViewController.h
//  EmpaLinkMultideviceTutorial
//
//  Created by Alberto Guarino on 05/12/14.
//  Copyright (c) 2014 Empatica. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <EmpaLink-ios-0.7-full/EmpaticaAPI-0.7.h>
#import "E4DeviceManager.h"

@interface ViewController : UIViewController <EmpaticaDelegate>

@end
