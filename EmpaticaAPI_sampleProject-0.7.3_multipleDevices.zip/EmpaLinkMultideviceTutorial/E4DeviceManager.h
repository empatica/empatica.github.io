//
//  E4DeviceManager.h
//  EmpaLinkMultideviceTutorial
//
//  Created by Alberto Guarino on 05/12/14.
//  Copyright (c) 2014 Empatica. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <EmpaLink-ios-0.7-full/EmpaticaAPI-0.7.h>

@interface E4DeviceManager : NSObject <EmpaticaDeviceDelegate>

@end
